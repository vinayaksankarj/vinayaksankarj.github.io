# Portfolio

Personal portfolio site. Static HTML and CSS, no build step.

Open `index.html` in a browser to preview it locally.
